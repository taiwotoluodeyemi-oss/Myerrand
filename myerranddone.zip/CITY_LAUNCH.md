# City Launch — One Zone

## Launch gate
- Supply gate: 15 launch-ready runners in the selected zone.
- Scoreboard windows: last 7 and 30 days.
- Sample size below 10 paid jobs: **Insufficient data**; do not score the zone.

## Health colors
- **GREEN:** median acceptance <12 min, accept rate ≥85%, completion ≥92%, dispute rate ≤2%.
- **YELLOW:** median acceptance <20 min, accept rate ≥70%, completion ≥85%, dispute rate ≤5%.
- **RED:** any scored metric misses the YELLOW bar.

These are operating thresholds, not guarantees. Use actual dashboard data only; never invent KPIs.
