# Stage 4

- Added config-driven market catalog and market API.
- Added market-aware zone/currency selection and paused-market protection.
- Added generic payment port with DemoProvider and existing Paystack adapter.
- Added JWT merchant API with idempotency and rate limiting.
- Added Stage 4 reliability/market contract tests.
- Existing errand money engine was not rewritten.
