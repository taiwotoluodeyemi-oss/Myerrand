# Backend Deployment

The production backend is intended to run as a Node.js application on GO54 cPanel/Passenger.

See `docs/CLOUDFLARE_GO54_GITHUB_DEPLOYMENT.md` for the complete deployment procedure and required environment variables.
