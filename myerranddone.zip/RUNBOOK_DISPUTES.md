# Runbook: Disputes

## What happened
An errand or payment dispute is open or requires review.

## Operator checks
Review the dispute reason, errand state, payment/hold state, evidence, market and zone.

## Safe action
Use the existing dispute workflow and existing money service for any release/refund resolution.

## Escalation
Escalate suspected fraud, conflicting evidence, or financial-integrity anomalies.

## What NOT to do
Do not resolve by directly changing balances, holds, or dispute rows.
