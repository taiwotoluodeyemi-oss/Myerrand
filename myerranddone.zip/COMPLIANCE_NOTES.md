# Compliance Notes

Stage 7 adds operational records for verification and policy acceptance. It does not constitute legal advice or a regulatory determination.

## Verification

- Manual admin approval is the primary path.
- No KYC vendor is required.
- Verification documents must remain in private storage; do not expose raw government ID images from a public static folder.
- A market can require approved runners before acceptance.

## Liability / insurance

`insurance_mode=off` provides no insurance acknowledgement flow.

`insurance_mode=ack_only` records that the user acknowledged the platform liability wording. **This does not mean the user is insured and the product must never describe it as active insurance.**

## Policies

Terms, privacy, escrow disclosure and runner agreement are versioned and accepted explicitly. Version changes require fresh acceptance for the gated action.

Obtain legal review for each market before commercial launch, including wallet/escrow treatment, consumer protection, privacy, employment/contractor status, insurance/liability and record retention.
