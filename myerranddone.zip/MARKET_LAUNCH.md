# Market Launch

Stage 4 markets are config-driven. Add a market with an id, ISO2 country, default currency, zones, status, supply gate and support email. Start `draft`, build supply, move to `soft_launch`, then `live`. `paused` markets should warn/block new demand. Reliability must show `Insufficient data` below the configured sample threshold.
