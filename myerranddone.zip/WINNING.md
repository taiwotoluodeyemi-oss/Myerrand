# Winning the First Zone

Operate one zone before expanding. Build supply first, then create real/test demand in-zone.

Track completed jobs, repeat clients, returning runners, acceptance speed, completion, and disputes. A healthy operating loop is more important than installs.

Use the scoreboard to decide whether the zone has enough evidence to expand. If sample size is below 10 paid jobs, treat the result as **Insufficient data** rather than a positive or negative score.
