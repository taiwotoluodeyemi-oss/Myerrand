# Runbook: Account Security

## What happened
Suspicious login activity, verification concerns, or a compromised account is reported.

## Operator checks
Review authentication/audit events, account status, organization context, and relevant security alerts. Minimize access to sensitive records.

## Safe action
Use the existing account deactivation/status and MFA/security workflows. Audit every privileged access.

## Escalation
Escalate suspected credential compromise, unauthorized sensitive-data access, or repeated verification abuse to the security owner.

## What NOT to do
Do not request passwords, JWTs, API keys, government IDs, or webhook secrets in tickets or chat.
