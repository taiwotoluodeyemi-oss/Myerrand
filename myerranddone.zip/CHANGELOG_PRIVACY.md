# Changelog — Privacy / Compliance Operations (P11)

## Added

- Operational privacy data map and classification.
- Configurable retention metadata and database migration `21-privacy-controls.sql`.
- Privacy-aware account deactivation/anonymization for MySQL.
- Preservation of financial/accounting records during deactivation.
- Verification-document retention metadata and cleanup during deactivation.
- Admin-only sensitive verification access audit trail.
- Authenticated privacy-safe errand export.
- Privacy-safe admin trust export.
- Privacy operations endpoints under `/api/privacy`.
- Escrow disclosure included in payment-intent responses.
- Explicit legal-review warnings in privacy/compliance documentation.
- Regression tests covering policy acceptance, sensitive access, safe exports, deactivation, and verification protection.
